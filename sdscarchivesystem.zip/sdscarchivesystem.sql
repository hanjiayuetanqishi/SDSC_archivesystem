-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2026 at 05:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sdscarchivesystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `capstone`
--

CREATE TABLE `capstone` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `authors` varchar(255) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `course` varchar(100) DEFAULT NULL,
  `leader` varchar(100) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `adviser` varchar(100) DEFAULT NULL,
  `abstract` text DEFAULT NULL,
  `keywords` text DEFAULT NULL,
  `pdf` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `department_code` varchar(30) DEFAULT NULL,
  `department_name` varchar(255) DEFAULT NULL,
  `chairperson` varchar(255) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `research`
--

CREATE TABLE `research` (
  `id` int(11) NOT NULL,
  `research_type` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `authors` text DEFAULT NULL,
  `adviser` varchar(255) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `academic_year` varchar(50) DEFAULT NULL,
  `keywords` text DEFAULT NULL,
  `abstract` text DEFAULT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `pdf_file` varchar(255) DEFAULT NULL,
  `status` varchar(30) DEFAULT 'Pending',
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `thesis`
--

CREATE TABLE `thesis` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `authors` text NOT NULL,
  `department` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `year` year(4) NOT NULL,
  `adviser` varchar(150) DEFAULT NULL,
  `abstract` text DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `pdf` varchar(255) DEFAULT NULL,
  `pdf_file` varchar(255) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Pending',
  `cover_image` varchar(255) DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `type` varchar(50) NOT NULL DEFAULT 'Thesis'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `thesis`
--

INSERT INTO `thesis` (`id`, `student_id`, `title`, `authors`, `department`, `course`, `year`, `adviser`, `abstract`, `keywords`, `pdf`, `pdf_file`, `status`, `cover_image`, `uploaded_by`, `created_at`, `type`) VALUES
(8, 5, 'AUTOMATA ACTIVITY', 'HAnnahasuchuc', 'College of Engineering and Computer Related Studies', 'Bs In Computer Science', '2026', 'Sir John Carlo Silmaro', 'afafasfasfas', 'Automata, Activity, 1', NULL, 'research_6aa63d636dbd27.00922736.pdf', 'Approved', NULL, NULL, '2026-09-13 06:06:27', 'Thesis'),
(9, 5, 'Connecting Safety and Technology conTech a wearable arduino', 'John Francis Mañibo, John Menard Marcelo, Mhannior Azupardo', 'College of Engineering and Computer Related Studies', 'BACHELOR SCIENCE IN COMPUTER SCIENCE', '2024', 'Mr. John Carlo D. Silmaro', 'asdasdasd', 'Connecting, Wearable, Arduino, Safety, Technology, conTech', NULL, 'research_6abfd2b0070083.60865184.pdf', 'Approved', NULL, NULL, '2026-10-02 15:50:08', 'Capstone'),
(10, 5, 'Library System', 'John Francis Mañibo, John Menard Marcelo, Mhannior Azupardo', 'College of Engineering and Computer Related Studies', 'BACHELOR SCIENCE IN COMPUTER SCIENCE', '2024', 'Mr. Joseph Edward Samson', 'adadadas', 'Library, System, Log, Records, Book, Author, Published Date', NULL, 'research_6abfd86f07ff03.68258849.pdf', 'Approved', NULL, NULL, '2026-10-02 16:14:39', 'Thesis'),
(11, 5, 'SpotFinder', 'John Francis Mañibo, John Menard Marcelo, Mhannior Azupardo', 'College of Engineering and Computer Related Studies', 'BACHELOR SCIENCE IN COMPUTER SCIENCE', '2024', 'Ms. Princess Sarah Lunar', 'asadsda', 'Spot, Finder, Arduino, spaces, place, car, availability', NULL, 'research_6abfda4fc49901.20834356.pdf', 'Approved', NULL, NULL, '2026-10-02 16:22:39', 'Thesis');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `student_id` varchar(30) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `course` varchar(100) DEFAULT NULL,
  `year_level` varchar(20) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('Admin','Student') DEFAULT 'Student',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `student_id`, `firstname`, `lastname`, `email`, `contact`, `department`, `course`, `year_level`, `username`, `password`, `role`, `created_at`) VALUES
(4, 'ADMIN-001', 'System', 'Administrator', 'admin@sdsc.edu.ph', '00000000000', 'ADMIN', 'ADMIN', 'ADMIN', 'admin', '$2y$10$lwKsAgO5QHLLBR6AhXsTxu9pDlYvtM3VX4cA7OON8yUcvLYoCXsKK', 'Admin', '2026-07-19 02:01:51'),
(5, 'c-076', 'Hannah Mae', 'Rejano', 'hannamaerejano@gmail.com', '09948703459', 'ECORS', 'Bs In Computer Science', '4th Year', 'hannah_rejano', '$2y$10$Id./62trTMOtmypgQ6DcpuWXBv1677ofj1ikKL6/VQBDomLeyYHe6', 'Student', '2026-09-13 03:06:11'),
(6, 'c22-096', 'Romel', 'Gerongco', 'romelsemortin1234@gmail.com', '0929 767 8732', 'ECORS', 'BACHELOR SCIENCE IN COMPUTER SCIENCE', '5th Year', 'romel_student', '$2y$10$Qx5BmjJw4oY/DegpqO59Tu0vk/5ReVR8htKkIF7jpaH.IH5/igaWu', 'Student', '2026-10-05 05:25:32'),
(7, 'C22-171', 'Shane', 'Randy Dumancas', 'Dumancassr2003@gmail.com', '0916 4124 354', 'CCJ', 'BACHELOR OF SCIENCE IN CRIMINAL JUSTICE', '4th Year', 'C22-171', '$2y$10$rtOoNDGPabPb/Z0EWMRfeuMN9mrzWTN9CRCLmjsDWjEzTqFX3j6Ki', 'Student', '2026-10-06 15:15:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `capstone`
--
ALTER TABLE `capstone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `research`
--
ALTER TABLE `research`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thesis`
--
ALTER TABLE `thesis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `capstone`
--
ALTER TABLE `capstone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `research`
--
ALTER TABLE `research`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `thesis`
--
ALTER TABLE `thesis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
